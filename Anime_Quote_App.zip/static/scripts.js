async function getQuote(category) {
  const response = await fetch("/get_quote", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ category: category })
  });

  const data = await response.json();
  document.getElementById("quote").innerText = data.quote;
  document.body.style.backgroundImage = `url('/static/${data.bg}')`;
}