import random

quotes = {
    "motivational": [
        "Your name may not be written in history books, but you can write your own saga.",
        "Every hero starts as a zero. Don’t stop until you evolve.",
        "Pain is not your enemy — it’s your teacher."
    ],
    "funny": [
        "Even Goku needs food — take a break!",
        "I’m not lazy, just on 'anime time'.",
        "Life is short. Watch one more episode!"
    ],
    "sad": [
        "Even the brightest stars burn out.",
        "It’s okay to cry, even ninjas do.",
        "Some goodbyes are the start of new arcs."
    ],
    "romantic": [
        "You had me at 'Nani?!'",
        "You're my plot twist in a filler episode.",
        "Every love story deserves its own anime."
    ]
}

def get_random_quote(category):
    return random.choice(quotes.get(category, ["No quotes available."]))