# 🌸 Anime Quote Universe

A beautiful anime-themed quote generator with background shuffling, anime music, and four quote categories.

## 🎯 Features
- Random anime-style quotes (Motivational, Funny, Sad, Romantic)
- Background image shuffling (10 backgrounds)
- Anime music autoplay
- Stylish glowing UI with anime vibes
- Built with Flask
- Deploy-ready on Google Cloud

## 🚀 Running Locally

```bash
pip install -r requirements.txt
python app.py
```

## ☁ Deploying on Google Cloud

```bash
gcloud app deploy
```

## 📁 Structure

- `app.py` - Flask backend
- `quotes.py` - Quote logic
- `static/` - Music, JS, CSS, backgrounds
- `templates/index.html` - Frontend