from flask import Flask, render_template, request, jsonify
from quotes import get_random_quote
import random

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_quote", methods=["POST"])
def quote():
    category = request.json.get("category")
    quote = get_random_quote(category)
    bg_number = random.randint(1, 10)
    return jsonify({"quote": quote, "bg": f"backgrounds/bg{bg_number}.jpg"})

if __name__ == "__main__":
    app.run(debug=True)